import java.util.Scanner;

public class ArithmeticProg {
    public static void main(String[] args) {
        Scanner read = new Scanner(System.in);

        System.out.print("Sila masukkan nombor pertama: ");
        int num1 = read.nextInt();

        System.out.print("Masukkan nombor kedua: ");
        int num2 = read.nextInt();

        System.out.println("Tambah: " + (num1 + num2));
        System.out.println("Tolak: " + (num1 - num2));
        System.out.println("Bahagi: " + (num1 * num2));
        System.out.println("Darab: " + (num1 / num2));
        System.out.println("Baki: " + (num1 % num2));

        read.close();
    }
}
