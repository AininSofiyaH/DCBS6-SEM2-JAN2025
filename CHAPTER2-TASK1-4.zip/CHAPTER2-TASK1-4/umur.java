import java.util.Scanner;


public class umur {
    public static void main(String[] args) {
        Scanner baca = new Scanner(System.in);
        
        System.out.print("Masukkan tarikh lahir anda: ");
        int birthYear = baca.nextInt();
        
        int age = 2025 - birthYear;
        
        System.out.println("Age: " + age + " years old");
        
        baca.close();
    }
}
