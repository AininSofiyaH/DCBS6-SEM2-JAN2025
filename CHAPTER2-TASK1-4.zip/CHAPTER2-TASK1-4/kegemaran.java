import java.util.Scanner;

public class kegemaran {
    public static void main(String[] args) {
        Scanner baca = new Scanner(System.in);

        
        System.out.print("Sila masukkan nama: ");
        String name = baca.nextLine();

       
        System.out.print("Masukkan umur: ");
        int age = baca.nextInt();
        baca.nextLine(); 

        
        System.out.print("Masukkan hobi: ");
        String hobby = baca.nextLine();

    
        System.out.print("Masukkan makanan kegemaran: ");
        String favoriteFood = baca.nextLine();

       
        System.out.println("Nama: " + name);
        System.out.println("Umumr: " + age);
        System.out.println("Hobi: " + hobby);
        System.out.println("Makanan kegemaran: " + favoriteFood);

        baca.close();
    }
}
