import java.util.Scanner;

public class studentmark {
    public static void main(String[] args) {
        Scanner baca = new Scanner(System.in);
        
        System.out.print("Sila masukkan nama: ");
        String name = baca.nextLine();
        
        System.out.print("Masukkan student id: ");
        String id = baca.nextLine();
        
        System.out.print("Masukkan subjek: ");
        String subject = baca.nextLine();
        
        System.out.print("Markah test 1: ");
        double test1 = baca.nextDouble();
        
        System.out.print("Markah test 2: ");
        double test2 = baca.nextDouble();
        

        double average = (test1 + test2) / 2;
        
        System.out.println("Name: " + name);
        System.out.println("ID: " + id);
        System.out.println("Subject: " + subject);
        System.out.println("Average Mark: " + average);
        
        baca.close();
    }
}
