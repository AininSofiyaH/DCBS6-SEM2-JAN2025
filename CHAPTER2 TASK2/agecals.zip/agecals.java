/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaapplication10;

import javax.swing.JOptionPane;

/**
 *
 * @author lammm
 */
public class JavaApplication10 {

    /**
     * @param args the command line arguments
     */
public void main(String[] args) {

    String birthYear;
    String currentYear;
    int num1, num2, sub; //declare variable
    
    birthYear = JOptionPane.showInputDialog("Enter the birth year");
    currentYear = JOptionPane.showInputDialog("Enter the current year");
    
    
    num1 = Integer.parseInt(birthYear);
    num2 = Integer.parseInt (currentYear);
    sub = num2 - num1;

    System.out.println ("You're : " + sub);
    
}

