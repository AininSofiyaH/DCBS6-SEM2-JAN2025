
import java.util.Scanner;

public class Task1{
    public static void main(String[] args){
        int mark;
        
        Scanner input = new Scanner(System.in);
        
        System.out.print("Enter your mark : ");
        
        mark = input.nextInt();
        
        if(mark>= 80){
            System.out.println("Your grade is A.");}
        else if (mark >= 70) {
            System.out.println("Your grade is A-.");}
        else if (mark >= 50) {
            System.out.println("Your grade is C.");}
        else if (mark >= 40) {
            System.out.println("Your grade is D.");}
        else if (mark >= 0) {
            System.out.println("Your grade is F.");}
            
    }
}
