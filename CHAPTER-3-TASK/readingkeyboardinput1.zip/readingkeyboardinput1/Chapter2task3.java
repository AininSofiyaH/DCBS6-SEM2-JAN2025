/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package readingkeyboardinput1;

/**
 *
 * @author Ainin Sofiya Hisham
 */
public class Chapter2task3 {
    
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
