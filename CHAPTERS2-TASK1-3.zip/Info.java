/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author U S E R
 */
import java.util.Scanner;
public class Info {

    public static void main(String[] args) {
        Scanner min = new Scanner(System.in);
        String name,age,hobby,food;
        
        System.out.print("Enter Your Name: ");
        name = min.nextLine();
        
        System.out.print("Enter Your Age: ");
        age = min.nextLine();
        
        System.out.print("Enter Your Hobby: ");
        hobby = min.nextLine();
        
        System.out.print("Enter Your Fav Food: ");
        food = min.nextLine();
        
        System.out.println("\n============= YOUR INFO ================");
        System.out.println("Name    : " + name);
        System.out.println("Age     : " + age);
        System.out.println("Hobby   : " + hobby);
        System.out.println("Fav Food: " + food);
        System.out.println("========================================");
    }
    
}
