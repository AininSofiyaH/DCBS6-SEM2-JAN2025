/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author U S E R
 */
import javax.swing.JOptionPane;
public class CalAge {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       String firstNumber;
       String secondNumber;
       int current_year, birth_year, age;
       
       // Prompt user to enter the first integer
       firstNumber = JOptionPane.showInputDialog("Enter Current Year: ");
       // Prompt user to enter the second integer
       secondNumber = JOptionPane.showInputDialog("Enter Birth Year: ");

       // Convert input strings to integers
       current_year = Integer.parseInt(firstNumber);
       birth_year = Integer.parseInt(secondNumber);

       // Calculate the age
       age = current_year - birth_year;

       // Display the result
       JOptionPane.showMessageDialog(null, "Your age is " + age, "Results", JOptionPane.PLAIN_MESSAGE);

       // Exit the program
       System.exit(0);
    }
}
   
    
}
