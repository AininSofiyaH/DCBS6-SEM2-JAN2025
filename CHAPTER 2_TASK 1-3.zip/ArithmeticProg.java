import java.util.Scanner;

public class ArithmeticProg {
    public static void main(String[] args) {
        try (Scanner in = new Scanner(System.in)) {
            System.out.print("Enter first number: ");
            int num1 = in.nextInt();
            
            System.out.print("Enter second number: ");
            int num2 = in.nextInt();
            
            System.out.println("Sum: " + (num1 + num2));
            System.out.println("Difference:" + (num1 - num2));
            System.out.println("product: " + (num1 * num2));
            System.out.println("Quotient: " + (num2 != 0 ? (num1 / num2) : "Undefined"));
            System.out.println("Remainder: " + (num2 != 0 ? (num1 % num2) : "Undefined"));
        }
    }
}
