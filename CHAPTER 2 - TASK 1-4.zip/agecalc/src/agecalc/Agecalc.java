/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package agecalc;

/**
 *
 * @author GMI-USER
 */
import java.util.Scanner;
public class Agecalc {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String name;
        int birth_year, current_year, age;
        Scanner read = new Scanner (System.in);
        
        System.out.print ("Please enter your name : ");
        name = read.nextLine();
        
        System.out.print ("Please enter the year you want :");
        current_year = read.nextInt();
        
        System.out.print ("Please enter your birth year :");
        birth_year = read.nextInt();
        
        read.close();
        
        age = current_year - birth_year;
        
        System.out.println ("Your current age is "+age);
        System.out.println ("Thank for using the system!!");
        
    }
    
}
