/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package averagemark;

/**
 *
 * @author GMI-USER
 */
import java.util.Scanner;
public class AverageMark {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String name, stuID, subject;
        int test1, test2;
        double average;
        Scanner baca = new Scanner (System.in);
        
        System.out.print ("Please enter your name :");
        name = baca.nextLine();
        
        System.out.print ("Please enter your student ID :");
        stuID = baca.nextLine();
        
        System.out.print ("Please enter the subject :");
        subject = baca.nextLine();
        
        System.out.print ("Please enter your mark for test 1 :");
        test1 = baca.nextInt();
        
        System.out.print ("Please enter your mark for test 2 :");
        test2 = baca.nextInt();
        
        baca.close();
        
        average = (test1 + test2)/2;
        
        System.out.println ("Name : "+name);
        System.out.println ("Student ID : "+stuID);
        System.out.println ("Subject : "+subject);
        System.out.println ("Average mark for test 1 and test 2 : "+average);
    }
    
}
