/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package arithmeticprog;

/**
 *
 * @author GMI-USER
 */
import java.util.Scanner;

public class ArithmeticProg {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int num1, num2;
        int add, substract, multiply, divide, remainder;
        Scanner arithmetic = new Scanner(System.in);
        
        System.out.print ("Please enter the first value : ");
        num1 = arithmetic.nextInt();
        
        System.out.print ("Please enter the second value : ");
        num2 = arithmetic.nextInt();
        arithmetic.close();
        
        add = num1 + num2;
        substract = num1-num2;
        multiply = num1 * num2;
        divide = num1/num2;
        remainder = num1 % num2;
        
        System.out.println ("==================================================");
        System.out.println ("The sum of the addition is " +add);
        System.out.println ("The sum of substraction is " +substract);
        System.out.println ("The sum of multiplication is " +multiply);
        System.out.println ("The sum of division is " +divide);
        System.out.println ("The remainder for above integers is " +remainder);
        System.out.println ("==================================================");
        System.out.println ("        THANK YOU FOR USING THE SYSTEM!           ");
    }
    
}
