/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package biography;

/**
 *
 * @author GMI-USER
 */
import java.util.Scanner;
public class Biography {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String name, hobby, fav_food;
        int age;
        Scanner bio = new Scanner (System.in);
        
        System.out.println ("Hello there! Welcome to the system!!");
        System.out.print ("Enter your name : ");
        name = bio.nextLine();
        
        System.out.print ("Enter your age : ");
        age = bio.nextInt();
        
        bio.nextLine();
        System.out.print ("Enter your hobby : ");
        hobby = bio.nextLine();
        
        System.out.print ("Enter your favourite food : ");
        fav_food = bio.nextLine();
        
        bio.close();
        
        System.out.println ("Name : "+name); 
        System.out.println ("Age : "+age);
        System.out.println ("hobby : "+hobby);
        System.out.println ("Favourite food : "+fav_food);
        System.out.println ("Thank you for using this system !! <3");
        
        
    }
    
}
