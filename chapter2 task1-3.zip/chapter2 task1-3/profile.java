import java.util.Scanner;

public class profile {

    public static void main(String[] args){

        String name, hobby, fav_food;
        int age;
        Scanner baca = new Scanner (System.in);

        System.out.println("Masukkan nama anda :");
        name = baca.nextLine();

        System.out.println("Masukkan umur anda :");
        age = baca.nextInt();
        baca.nextLine();

        System.out.println("Masukkan hobi anda :");
        hobby = baca.nextLine();

        System.out.println("Masukkan makanan kegemaran anda :");
        fav_food = baca.nextLine();
        baca.close();

        System.out.println("Nama : " +name);
        System.out.println("Umur : " +age);
        System.out.println("Hobi : " +hobby);
        System.out.println("Makanan kegemaran : " +fav_food);

    }
}