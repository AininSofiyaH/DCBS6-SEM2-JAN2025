import javax.swing.JOptionPane;
public class ArithmeticProg {
    public static void main(String[] args){
        String firstGUI;
        String secondGUI;
        int num1, num2, add, minus, mult, div, modulus;

        firstGUI = JOptionPane.showInputDialog("Enter the first integer");
        secondGUI = JOptionPane.showInputDialog("Enter the second integer");

        num1 = Integer.parseInt(firstGUI);
        num2 = Integer.parseInt(secondGUI);
        add = num1 + num2;
        minus = num1 - num2;
        mult = num1 * num2;
        div = num1 / num2;
        modulus = num1 % num2;

        JOptionPane.showMessageDialog(null, " " +num1 +" + " +num2 +" = " +add, "Result", JOptionPane.PLAIN_MESSAGE);
        JOptionPane.showMessageDialog(null, " " +num1 +" - " +num2 +" = " +minus, "Result", JOptionPane.PLAIN_MESSAGE);
        JOptionPane.showMessageDialog(null, " " +num1 +" X " +num2 +" = " +mult, "Result", JOptionPane.PLAIN_MESSAGE);
        JOptionPane.showMessageDialog(null, " " +num1 +" / " +num2 +" = " +div, "Result", JOptionPane.PLAIN_MESSAGE);
        JOptionPane.showMessageDialog(null, " " +num1 +" % " +num2 +" = " +modulus, "Result", JOptionPane.PLAIN_MESSAGE);

        System.exit(0);


    }
}