import javax.swing.JOptionPane;

public class age_calc {
    public static void main(String[] args) {
        String firstGUI, secondGUI;
        int year1, year2, age;

        firstGUI = JOptionPane.showInputDialog("Enter your year of birth");
        secondGUI = JOptionPane.showInputDialog("Enter the current year");
        year1 = Integer.parseInt(firstGUI);
        year2 = Integer.parseInt(secondGUI);
        age = year2 - year1;

        JOptionPane.showMessageDialog(null, "Your age for this year is" +age , "Result", JOptionPane.PLAIN_MESSAGE);
        System.exit(0);

    }
}