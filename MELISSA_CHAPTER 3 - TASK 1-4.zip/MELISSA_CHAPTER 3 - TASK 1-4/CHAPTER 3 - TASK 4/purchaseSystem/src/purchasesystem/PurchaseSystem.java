/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package purchasesystem;

/**
 *
 * @author PC STUDENT 04
 */
import java.util.Scanner;
public class PurchaseSystem {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int choice;
        Scanner userchoice = new Scanner (System.in);
       
        System.out.println ("-----------------------------------------------------------------");
        System.out.println ("              WELCOME TO RAFAYEL SEAFOOD RESTAURANT!!!!          ");
        System.out.println ("-----------------------------------------------------------------");
        System.out.println ("");
        System.out.println ("                          LIST OF FOOD SETS                      ");
        System.out.println ("1. CLAM SOUP WITH ICED LEMON TEA                       - RM 20");
        System.out.println ("2. SEAFOOD BOIL WITH ICED VICO                         - RM 11");
        System.out.println ("3. FISH SOUP WITH ICED ORANGE JUICE                    - RM 12");
        System.out.println ("-----------------------------------------------------------------");
        
        System.out.print ("WHAT FOOD SETS DO YOU WANT TO BUY? FOOD SET (1/2/3) : ");
        choice = userchoice.nextInt();
        
        switch (choice){
            case 1 : System.out.println ("ITEM PURCHASED : CLAM SOUP WITH ICED LEMON TEA IS ON THE WAY."); break;
            case 2 : System.out.println ("ITEM PURCHASED : SEAFOOD BOIL WITH ICED VICO IS ON THE WAY."); break;
            case 3 : System.out.println ("ITEM PURCHASED : FISH SOUP WITH ICED ORANGE JUICE  IS ON THE WAY."); break;
            default : System.out.println ("INVALID CHOICE."); break;
        }
        
    }
    
}
