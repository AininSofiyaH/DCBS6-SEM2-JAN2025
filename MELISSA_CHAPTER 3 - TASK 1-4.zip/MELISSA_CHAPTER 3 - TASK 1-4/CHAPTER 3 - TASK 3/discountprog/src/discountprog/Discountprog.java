/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package discountprog;

/**
 *
 * @author PC STUDENT 04
 */
import java.util.Scanner;
public class Discountprog {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String itemName, colourCode;
        double price, totalPrice, discountRate = 0, afterDiscount, rate = 0;
        int quantity;
        Scanner barang = new Scanner (System.in);
        
        System.out.println ("----------------------------------------------------------------------");
        System.out.println ("                   WELCOME TO HOMURA'S BAG STORE!!!!!");
        System.out.println ("----------------------------------------------------------------------");
        
        System.out.println ("1. Capybara bag");
        System.out.println ("2. Barbie bag");
        System.out.println ("3. My Little Pony bag");
        System.out.println ("Please choose your item : ");
        itemName = barang.nextLine();
        
        System.out.println ("Please enter the quantity of the bag(s) : ");
        quantity = barang.nextInt();
        
        System.out.println ("Please enter the price per item of the bag : ");
        price = barang.nextDouble();
        
        barang.nextLine();
        System.out.println ("Please choose the colour code. It can be found at the price tag.");
        System.out.println ("Pink = 10%");
        System.out.println ("Blue = 20%");
        System.out.println ("Purple = 30%");
        System.out.println ("Please enter the colour code : ");
        colourCode = barang.nextLine();
        barang.close();
        
        switch (colourCode){
            case "Pink" : discountRate= 0.10; break;
            case "Blue" : discountRate= 0.20; break;
            case "Purple" : discountRate= 0.30; break;
            default : System.out.println ("Invalid colour, no discount will be applied.");
        
        }
        
        rate = 1 - discountRate;
        totalPrice = price * quantity;
        afterDiscount = totalPrice * rate;
        
        System.out.println ("-------------------------------RECEIPT--------------------------------");
        System.out.println ("Item name : "+itemName);
        System.out.println ("Quantity : "+quantity);
        System.out.println ("Price : "+price);
        System.out.println ("Total price : "+totalPrice);
        System.out.println ("Discount rate : "+discountRate);
        System.out.println ("Price after discount : "+afterDiscount);
        System.out.println ("----------------------------------------------------------------------");
    
    }
    
}
