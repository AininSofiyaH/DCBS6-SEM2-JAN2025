/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package arithmeticprog;

/**
 *
 * @author PC STUDENT 04
 */
import java.util.Scanner;
public class ArithmeticProg {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String name;
        int value1, value2, add, substract, multiply, menu;
        float division, remainder;
        Scanner operator = new Scanner (System.in);
        
        System.out.print ("Please enter your name: ");
        name = operator.nextLine();
        System.out.print ("Please enter your first value: ");
        value1 = operator.nextInt();
        System.out.print ("Please enter your second value: ");
        value2 = operator.nextInt();
        
        System.out.println ("1. Addition ");
        System.out.println ("2. Substaction ");
        System.out.println ("3. Multiplication ");
        System.out.println ("4. Division ");
        System.out.println ("5. Modulus ");
        System.out.print ("Please enter your wanted operation: ");
        menu = operator.nextInt();
        operator.close();
        
        add = value1 + value2;
        substract = value1 - value2;
        multiply = value1 * value2;
        division = value1 / value2;
        remainder = value1 % value2;
        
        switch (menu){
            case 1: System.out.println ("The total for addition is "+add); break;
            case 2 : System.out.println ("The total for substraction is "+substract); break;
            case 3 : System.out.println ("The total for multiplication is "+multiply); break;
            case 4 : System.out.println ("The result of the division is "+division); break;
            case 5 : System.out.println ("The remainder for the division is "+remainder); break;
            default : System.out.println ("Invalid operator. Try again."); break;
    }
    
}
}