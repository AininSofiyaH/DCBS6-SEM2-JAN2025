/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package grade;

/**
 *
 * @author PC STUDENT 04
 */
import java.util.Scanner;
public class Grade {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       int mark;
       char grade;
       Scanner testmark = new Scanner (System.in);
       
       System.out.println ("Please enter your test mark : ");
       mark = testmark.nextInt();
       testmark.close();
       
       if ( mark >= 80) {
           grade = 'A';
       }    else if ( mark >= 70){
           grade = 'B';
       }    else if ( mark >= 60){
           grade = 'C';
       }    else if ( mark >= 50){
           grade = 'D';
       }    else if ( mark >= 40){
           grade = 'E';
       }    else {
           grade = 'F';
       }
       System.out.println ("Your grade is : "+grade);
    }
}
