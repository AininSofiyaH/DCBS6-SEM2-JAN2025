/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package task4_chap2;

/**
 *
 * @author Damia
 */
import java.util.Scanner;
public class Task4_chap2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String name,subject;
         int id;
         float avm,ts1,ts2;
      Scanner userdata= new Scanner(System.in);
  
      System.out.println("Please enter your name:"); 
      name = userdata.nextLine();
      
      
      System.out.println("Please enter your ID:");
      id = userdata.nextInt();
      
      userdata.nextLine();
      System.out.println("Please enter subject name:"); 
      subject = userdata.nextLine();
      
     
      System.out.println("Please enter your mark in Test1(/100):"); 
      ts1 = userdata.nextFloat();
      
      System.out.println("Please enter your mark in Test2(/100):"); 
      ts2 = userdata.nextFloat();
     
      userdata.close();
      avm = (ts1+ts2)/2;
       System.out.println("Name :"+name);
       System.out.println("ID :"+id);
       System.out.println("Subject :"+subject);
       System.out.println("Average mark :"+avm);
    }
    
}
