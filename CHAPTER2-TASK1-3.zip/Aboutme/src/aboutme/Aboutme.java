package aboutme;
import java.util.Scanner;

public class Aboutme {

    public static void main(String[] args) {
        
        String name, hobby, favourite_food;
        String age;
        Scanner read = new Scanner (System.in);
        
        System.out.print("Please enter your name : ");
        name = read.nextLine();
        
        System.out.print("Please enter your age : ");
        age = read.nextLine();
        
        System.out.print("Please enter your hobby : ");
        hobby = read.nextLine();
        
        System.out.print("Please enter your favourite food : ");
        favourite_food = read.nextLine();
        
        read.close();
        
        System.out.println("My name is "+name);
        System.out.println("I am " +age);
        System.out.println("My hobby is "+hobby);
        System.out.println("My favourite food is " +favourite_food);
        
        
    }
    
}
