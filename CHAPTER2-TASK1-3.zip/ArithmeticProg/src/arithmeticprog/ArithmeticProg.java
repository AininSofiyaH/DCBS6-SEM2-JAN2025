package arithmeticprog;
import java.util.Scanner;

public class ArithmeticProg {

    
    public static void main(String[] args) {
        int a, b, answer;
        int plus, minus, multiply, divide, modulus;
        
        Scanner read = new Scanner (System.in);
        
        System.out.print("Please enter first number : ");
        a = read.nextInt();
        
        System.out.print("Please enter second number : ");
        b = read.nextInt();
        read.close();
        
        System.out.print("  a + b = ");
        System.out.println( a + b);
        System.out.print("  a - b = ");
        System.out.println( a - b);
        System.out.print(" a * b = ");
        System.out.println( a * b);
        System.out.print(" a / b = ");
        System.out.println( a / b);
        System.out.print(" a % b = ");
        System.out.println( a % b);
        
    }
    
}
