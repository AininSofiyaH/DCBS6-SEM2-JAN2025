package agecalc;
import java.util.Scanner;

public class Agecalc {

    public static void main(String[] args) {
        int age, current_year, birth_year; 

        Scanner read = new Scanner(System.in);
        
        System.out.print("Please enter the current year: ");
        current_year = read.nextInt(); 
        
        System.out.print("Please enter your birth year: ");
        birth_year = read.nextInt(); 
        read.close();
        
        age = current_year - birth_year;
        
        System.out.println("Your age is  " + age + " years old.");
    }
}

