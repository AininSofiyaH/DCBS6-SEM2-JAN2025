import java.util.Scanner;
public class Userput {
    public static void main(String[] args){
        String name;
        int age;
        String hobby;
        String food;
        try (Scanner in = new Scanner(System.in)) {
            name = in.nextLine();
            age = in.nextInt();
            hobby = in.nextLine();
            food = in.nextLine();
        }
        
        System.out.println("Name :" +name);
        System.out.println("Age :" +age);
        System.out.println("Hobby :" +hobby);
        System.out.println("Favourite food :" +food);
    }
}

