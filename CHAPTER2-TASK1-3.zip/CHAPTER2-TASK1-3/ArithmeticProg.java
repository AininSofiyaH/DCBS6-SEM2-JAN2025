import javax.swing.JOptionPane;

public class ArithmeticProg {
    public static void main(String[] args) {
        int num1 = Integer.parseInt(JOptionPane.showInputDialog("Enter the first integer:"));
        int num2 = Integer.parseInt(JOptionPane.showInputDialog("Enter the second integer:"));
        
        int sum = num1 + num2;
        int subs = num1 - num2;
        int mul = num1 * num2;
        int mod = num1 % num2;
        int div = num1 / num2;
        
        System.out.println("Summation: " +sum);
        System.out.println("Substraction: " +subs);
        System.out.println("Multiplication: " +mul);
        System.out.println("Division: " +div);
        System.out.println("Modulus: " +mod);
        
       
    }
}


