import javax.swing.JOptionPane;

public class AgeCalc {
    public static void main(String[] args) {
        int year1 = Integer.parseInt(JOptionPane.showInputDialog("What year do you want to check?:"));
        int year2 = Integer.parseInt(JOptionPane.showInputDialog("What's your birth year:"));
        
        int subs = year1 - year2;
        
        System.out.println("Your age is: " +subs);
    }
}