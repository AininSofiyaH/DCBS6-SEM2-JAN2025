/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package task_2;

import java.util.Scanner;

/**
 *
 * @author ASUS
 */
public class Task_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String name, hobby, fav_food;
        int age;
        Scanner baca = new Scanner (System.in);
        
        System.out.print ("Enter your name : ");
        name = baca.nextLine();
        
        System.out.print ("Enter your age :  ");
        age = baca.nextInt();
        
        baca.nextLine();
        System.out.print ("Enter your hobby : ");
        hobby = baca.nextLine();
        
        System.out.print ("Enter your fav food : ");
        fav_food = baca.nextLine();
        
        System.out.println ("Name : " +name);
        System.out.println ("Age : " +age);
        System.out.println ("Hobby : " +hobby);
        System.out.println ("Favfood : " +fav_food);
    }
    
    }
    

