/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package arithmeticprog;

import java.util.Scanner;

/**
 *
 * @author ASUS
 */
public class ArithmeticProg {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int num1, num2;
        Scanner objectname = new Scanner (System.in);
        
        System.out.println("Enter the first digit : ");
        num1 = objectname.nextInt();
        
        System.out.println("Enter the second digit : ");
        num2 = objectname.nextInt();
        
        System.out.println("Tambah :" + num1 + " + " + num2 + " = " + (num1+num2));
        System.out.println("Tolak :" + num1 + " - " + num2 + " = " + (num1-num2));
        System.out.println("Darab :" + num1 + " * " + num2 + " = " + (num1*num2));
        System.out.println("Bahagi :" + num1 + " / " + num2 + " = " + (num1/num2));
        System.out.println("Tambah : " + num1 + " % " + num2 + " = " + (num1%num2));
        }
}
    

