import javax.swing.JOptionPane;
public class AgeCalc {

 public static void main(String[] args) {

    String birthYear;
    String currentYear;
    int num1, num2, sub; //declare variable
    
    birthYear = JOptionPane.showInputDialog("Enter the birth year");
    currentYear = JOptionPane.showInputDialog("Enter the current year");
    
    
    num1 = Integer.parseInt(birthYear);
    num2 = Integer.parseInt (currentYear);
    sub = num2 - num1;

    System.out.println ("You're : " + sub);
 }
}








    


