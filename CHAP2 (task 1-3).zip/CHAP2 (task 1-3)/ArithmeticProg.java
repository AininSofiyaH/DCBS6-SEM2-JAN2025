/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package arithmeticprog;

/**
 *
 * @author Nuwaira
 */
import java.util.Scanner;
public class ArithmeticProg {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner read = new Scanner(System.in); //initialize scanner
        
        System.out.println("Enter the first integer please : ");
        int num1= read.nextInt();
        
        System.out.println("Enter the second integer please : ");
        int num2 = read.nextInt();
        

        int addition = num1 + num2; 
        int subtraction = num1 - num2;
        int multiplication = num1 * num2;
        int division = num1 / num2;
        int modulus = num1 % num2;

        //output for arithmetic operations

        System.out.println (addition + ": addition");
        System.out.println ( subtraction + ": subtraction");
        System.out.println ( multiplication + ": multiplication");
        System.out.println (division + ": division");
        System.out.println (modulus + ": modulus");
        
   


    }
    
}
