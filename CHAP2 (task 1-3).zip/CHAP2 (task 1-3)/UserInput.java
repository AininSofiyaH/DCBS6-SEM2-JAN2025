/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package userinput;

/**
 *
 * @author Nuwaira
 */
import java.util.Scanner;
public class UserInput {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String name, hobby, favfood;
        int age;
        Scanner read = new Scanner(System.in); //initialize scanner
        
        System.out.print("Insert your name :");
        name = read.nextLine();
        System.out.print("Insert your age : ");
        age = read.nextInt();
        
        read.nextLine();
                
        System.out.print("What's your hobby : ");
        hobby = read.nextLine();
        System.out.print("What's your favfood : ");
        favfood = read.nextLine();
        
        read.close(); 
        
        System.out.println("Name: " + name);
        System.out.println("Age: " + age);
        System.out.println("Hobby: " + hobby);
        System.out.println("Favfood: " + favfood);




    }
    
}
