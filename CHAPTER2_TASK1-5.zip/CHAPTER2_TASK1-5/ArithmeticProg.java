/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package arithmeticprog;

/**
 *
 * @author Damia
 */
import java.util.Scanner;//ライブラリ。ないとScanが動かない（user input）
public class ArithmeticProg {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
      int firstnum,secondnum,tolak;//年齢の変数名をintとして定義
      int waru;
      //Scanを呼び出して準備する
      Scanner userdata= new Scanner(System.in);//declare new object for scanner
      // Reads a single line from the console
      // and stores into name variable
      //ユーザーに名前入力を促す
      System.out.println("Please enter 1st number:");
      //ここでユーザーからの入力を受け付ける
      firstnum = userdata.nextInt();//入力されたデータをnameに格納する。Lineはstring入れれる。
      
      // Reads a integer from the console
      // and stores into age variable
      //ユーザーに年齢入力を促す
      System.out.println("Please enter 2nd number:");
      secondnum = userdata.nextInt();//入力されたデータをageに格納する。intは整数のみ
      //scan名で閉じるのを忘れずに！
      userdata.close();
      tolak = firstnum - secondnum;
      waru = firstnum / secondnum;
      // Prints name and age to the console
      System.out.println(firstnum+"+"+secondnum+"="+firstnum+secondnum);
      System.out.println(firstnum+"-"+secondnum+"="+tolak);
      System.out.println(firstnum+"/"+secondnum+"="+waru);
      System.out.println(firstnum+"%"+secondnum+"="+firstnum%secondnum);
      System.out.println(firstnum+"*"+secondnum+"="+firstnum*secondnum);
    }
    
}
