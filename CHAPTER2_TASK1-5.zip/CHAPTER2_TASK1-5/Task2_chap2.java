/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package task2_chap2;

/**
 *
 * @author Damia
 */
import java.util.Scanner;
public class Task2_chap2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         String name,hobby,favfood;//年齢の変数名をintとして定義
         int age;
      Scanner userdata= new Scanner(System.in);//declare new object for scanner
  
      System.out.println("Please enter your name:"); //ユーザーに名前入力を促す
      //ここでユーザーからの入力を受け付ける
      name = userdata.nextLine();//入力されたデータをnameに格納する。Lineはstring入れれる。
      
      
      System.out.println("Please enter your age:");
      age = userdata.nextInt();
      
      userdata.nextLine();
      System.out.println("Please enter your hobby:"); 
      hobby = userdata.nextLine();
      
      System.out.println("Please enter your favorite food:"); 
      favfood = userdata.nextLine();
     
      userdata.close();
       System.out.println("Name :"+name);
       System.out.println("Age :"+age);
       System.out.println("hobby :"+hobby);
       System.out.println("Favorite food :"+favfood);
        
    }
    
}
