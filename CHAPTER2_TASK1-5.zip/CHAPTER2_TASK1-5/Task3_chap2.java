/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package task3_chap2;

/**
 *
 * @author Damia
 */
import java.util.Scanner;
public class Task3_chap2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int nowyear,birthyear,age;
      Scanner userdata= new Scanner(System.in);
      System.out.println("Please enter your birth year:");
      //ここでユーザーからの入力を受け付ける
      birthyear = userdata.nextInt();
      
      System.out.println("Please enter any year:");
      nowyear = userdata.nextInt();
      //scan名で閉じるのを忘れずに！
      userdata.close();
      age = nowyear - birthyear;
      System.out.println("Your  age on "+nowyear+" is:"+age);
    }
    
}
