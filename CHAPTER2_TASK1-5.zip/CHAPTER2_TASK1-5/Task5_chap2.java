/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package task5_chap2;

/**
 *
 * @author Damia
 */
import java.util.Scanner;
public class Task5_chap2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    String name;
         int qa;
         float disaf,pri,disc,total;
      Scanner userdata= new Scanner(System.in);
  
      System.out.println("Please enter item name:");
      name = userdata.nextLine();
      
      
      System.out.println("Please enter quantity:");
      qa = userdata.nextInt();
      
      System.out.println("Please enter price(RM):"); 
      pri = userdata.nextInt();
      
     
      System.out.println("Please enter discount rate(/100%):"); 
      disc = userdata.nextInt();
      
      userdata.close();
      total = pri*qa;
      
      disaf = total*(disc/100);
      System.out.println("Item Name:"+name);
      System.out.println("price:RM"+pri);
      System.out.println("Quantity :"+qa);
      System.out.println("total price:RM"+total);
      System.out.println("discunt rate:"+disc+"%");
      System.out.println("price after discount:RM"+disaf);
    }
    
}
